var _m_a_offline_item_8h =
[
    [ "MAOfflineItem", "interface_m_a_offline_item.html", "interface_m_a_offline_item" ],
    [ "MAOfflineItemStatus", "_m_a_offline_item_8h.html#ad5e7511876ea06decdba29e0d7c9d311", [
      [ "MAOfflineItemStatusNone", "_m_a_offline_item_8h.html#ad5e7511876ea06decdba29e0d7c9d311ac4007e8ff94d6cb3ba3f9253909487f0", null ],
      [ "MAOfflineItemStatusCached", "_m_a_offline_item_8h.html#ad5e7511876ea06decdba29e0d7c9d311ad88ce29ebfd231cf62c60a527ef19e6b", null ],
      [ "MAOfflineItemStatusInstalled", "_m_a_offline_item_8h.html#ad5e7511876ea06decdba29e0d7c9d311a5cc7f4828a9da3eeba45daa20095b9d0", null ],
      [ "MAOfflineItemStatusExpired", "_m_a_offline_item_8h.html#ad5e7511876ea06decdba29e0d7c9d311af037747b3555d945f27cb160d91ab96c", null ]
    ] ]
];