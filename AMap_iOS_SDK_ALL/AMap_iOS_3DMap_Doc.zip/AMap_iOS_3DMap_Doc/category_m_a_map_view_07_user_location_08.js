var category_m_a_map_view_07_user_location_08 =
[
    [ "setUserTrackingMode:animated:", "category_m_a_map_view_07_user_location_08.html#a66a7344a53c16b835cf69be67700c558", null ],
    [ "updateUserLocationRepresentation:", "category_m_a_map_view_07_user_location_08.html#ae89d50836be9fa5fc400189c10b33f4c", null ],
    [ "allowsBackgroundLocationUpdates", "category_m_a_map_view_07_user_location_08.html#a57e0ecdc4a5c017f98a6aab22bbda59d", null ],
    [ "customizeUserLocationAccuracyCircleRepresentation", "category_m_a_map_view_07_user_location_08.html#a5adbccc79c95b4d1149cad539f92e1c6", null ],
    [ "desiredAccuracy", "category_m_a_map_view_07_user_location_08.html#afa5de215ed32a13e4f60fd8aecd133c7", null ],
    [ "distanceFilter", "category_m_a_map_view_07_user_location_08.html#a52240891abf2d5459e65f990de64d277", null ],
    [ "headingFilter", "category_m_a_map_view_07_user_location_08.html#ae4286e60c93e3a3c66047b3cf9734cc7", null ],
    [ "pausesLocationUpdatesAutomatically", "category_m_a_map_view_07_user_location_08.html#ac9e77e401b495037ffa7351cbe3e64f8", null ],
    [ "showsUserLocation", "category_m_a_map_view_07_user_location_08.html#aa4de4f6217252dbc28116fa5fb31c30a", null ],
    [ "userLocation", "category_m_a_map_view_07_user_location_08.html#a1e0ba5be036d5246ba9f7470fbb6597f", null ],
    [ "userLocationAccuracyCircle", "category_m_a_map_view_07_user_location_08.html#a49c7ae3bac0e5e4206c4655497c5eea3", null ],
    [ "userLocationVisible", "category_m_a_map_view_07_user_location_08.html#a8e8ce48091e7c8c0155981b5d2ca99f4", null ],
    [ "userTrackingMode", "category_m_a_map_view_07_user_location_08.html#a4fa8d5b999f01d2dd3794e45d6388ada", null ]
];