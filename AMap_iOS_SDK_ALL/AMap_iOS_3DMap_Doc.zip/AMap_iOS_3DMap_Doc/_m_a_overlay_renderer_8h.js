var _m_a_overlay_renderer_8h =
[
    [ "MAOverlayRenderer", "interface_m_a_overlay_renderer.html", "interface_m_a_overlay_renderer" ],
    [ "kMAOverlayRendererDefaultFillColor", "_m_a_overlay_renderer_8h.html#a2ee48384435aaf6a59e1dd18a588657b", null ],
    [ "kMAOverlayRendererDefaultStrokeColor", "_m_a_overlay_renderer_8h.html#a9315ddf0349cafdc37ec428dc568fdb8", null ]
];