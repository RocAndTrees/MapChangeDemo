var interface_m_a_annotation_move_animation =
[
    [ "cancel", "interface_m_a_annotation_move_animation.html#a27d7f1ccc95ee12a34194c9ff1e0e76e", null ],
    [ "coordinates", "interface_m_a_annotation_move_animation.html#a9ffc33ddab0f46e68b6e7fbef6916dd8", null ],
    [ "count", "interface_m_a_annotation_move_animation.html#aef56bd2084c9a4fcbf0e06e3d60d5297", null ],
    [ "duration", "interface_m_a_annotation_move_animation.html#a6ee674b107c8c39405058591989b3d0a", null ],
    [ "elapsedTime", "interface_m_a_annotation_move_animation.html#af2a55b704bef3a317f36c8a26e0f04f6", null ],
    [ "isCancelled", "interface_m_a_annotation_move_animation.html#a5bd18c07a14014d1fd16714728cbaafa", null ],
    [ "name", "interface_m_a_annotation_move_animation.html#a5d7ca3dbc9aa9a17a520abb1f5c2cc24", null ]
];