var searchData=
[
  ['version',['version',['../interface_m_a_offline_map.html#a474670a85dc7e423e282566a5f5df9f2',1,'MAOfflineMap']]],
  ['visiblemaprect',['visibleMapRect',['../interface_m_a_map_view.html#a33b238dcdea708849ed9be11cd961240',1,'MAMapView']]]
];
