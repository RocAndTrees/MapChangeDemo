var searchData=
[
  ['kaccuracycircledefaultcolor',['kAccuracyCircleDefaultColor',['../_m_a_user_location_representation_8h.html#a3772016cba673eedbca5143e64a777a8',1,'MAUserLocationRepresentation.h']]],
  ['kmaoverlayrendererdefaultfillcolor',['kMAOverlayRendererDefaultFillColor',['../_m_a_overlay_renderer_8h.html#a2ee48384435aaf6a59e1dd18a588657b',1,'MAOverlayRenderer.h']]],
  ['kmaoverlayrendererdefaultstrokecolor',['kMAOverlayRendererDefaultStrokeColor',['../_m_a_overlay_renderer_8h.html#a9315ddf0349cafdc37ec428dc568fdb8',1,'MAOverlayRenderer.h']]]
];
