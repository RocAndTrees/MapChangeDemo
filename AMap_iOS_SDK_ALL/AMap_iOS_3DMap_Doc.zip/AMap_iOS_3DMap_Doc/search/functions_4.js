var searchData=
[
  ['getcoordinates_3arange_3a',['getCoordinates:range:',['../interface_m_a_multi_point.html#adb088c10f31c8ad2930e8af0200350e4',1,'MAMultiPoint']]],
  ['getmapstatus',['getMapStatus',['../interface_m_a_map_view.html#a4f25cca649b2bd657f71dd08f1545003',1,'MAMapView']]],
  ['getprojectionmatrix',['getProjectionMatrix',['../interface_m_a_overlay_renderer.html#a272f844a2fdf2c7c29b3d3ab6ca327aa',1,'MAOverlayRenderer']]],
  ['getviewmatrix',['getViewMatrix',['../interface_m_a_overlay_renderer.html#a17752e94b38a236bd7778e1bf195ac5f',1,'MAOverlayRenderer']]],
  ['glpointformappoint_3a',['glPointForMapPoint:',['../interface_m_a_overlay_renderer.html#a2d4b44782f2d65bea849753610349ec0',1,'MAOverlayRenderer']]],
  ['glpointsformappoints_3acount_3a',['glPointsForMapPoints:count:',['../interface_m_a_overlay_renderer.html#aacba123d46c1d20f5925fefe056e400e',1,'MAOverlayRenderer']]],
  ['glrender',['glRender',['../interface_m_a_overlay_renderer.html#aff00e281b17192a78c807e6ebe3a2125',1,'MAOverlayRenderer']]],
  ['glwidthforwindowwidth_3a',['glWidthForWindowWidth:',['../interface_m_a_overlay_renderer.html#a25aa32a0921135a71324601b7f4fb07f',1,'MAOverlayRenderer']]],
  ['groundoverlaywithbounds_3aicon_3a',['groundOverlayWithBounds:icon:',['../interface_m_a_ground_overlay.html#a6256970ff943ea13ce17c925e470d824',1,'MAGroundOverlay']]],
  ['groundoverlaywithcoordinate_3azoomlevel_3aicon_3a',['groundOverlayWithCoordinate:zoomLevel:icon:',['../interface_m_a_ground_overlay.html#aa7566913afb8ac6cca83f67906cf092b',1,'MAGroundOverlay']]]
];
