var searchData=
[
  ['updateuserlocationrepresentation_3a',['updateUserLocationRepresentation:',['../category_m_a_map_view_07_user_location_08.html#ae89d50836be9fa5fc400189c10b33f4c',1,'MAMapView(UserLocation)::updateUserLocationRepresentation:()'],['../interface_m_a_map_view.html#ae89d50836be9fa5fc400189c10b33f4c',1,'MAMapView::updateUserLocationRepresentation:()']]],
  ['urlfortilepath_3a',['URLForTilePath:',['../category_m_a_tile_overlay_07_custom_loading_08.html#aacc5d904fedafb39cc635c042fa56599',1,'MATileOverlay(CustomLoading)::URLForTilePath:()'],['../interface_m_a_tile_overlay.html#aacc5d904fedafb39cc635c042fa56599',1,'MATileOverlay::URLForTilePath:()']]]
];
