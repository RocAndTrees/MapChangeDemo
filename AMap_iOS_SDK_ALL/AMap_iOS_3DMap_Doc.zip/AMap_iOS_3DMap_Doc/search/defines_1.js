var searchData=
[
  ['ma_5fcustom_5fmap',['MA_CUSTOM_MAP',['../_m_a_config_8h.html#a71853293c03d1f5fcbf83d9d4accd926',1,'MAConfig.h']]],
  ['ma_5finclude_5fcache',['MA_INCLUDE_CACHE',['../_m_a_config_8h.html#a9d505e549528fcb823446a23a0867eef',1,'MAConfig.h']]],
  ['ma_5finclude_5findoor',['MA_INCLUDE_INDOOR',['../_m_a_config_8h.html#a3aaa6b8b3d9f1718a1fd5362a6107dc7',1,'MAConfig.h']]],
  ['ma_5finclude_5foffline',['MA_INCLUDE_OFFLINE',['../_m_a_config_8h.html#a3db51d6b8d16301a42ca14c8271d6409',1,'MAConfig.h']]],
  ['ma_5finclude_5foverlay_5fgeodesic',['MA_INCLUDE_OVERLAY_GEODESIC',['../_m_a_config_8h.html#aee78790b7b8c3303f37173f76c3e0036',1,'MAConfig.h']]],
  ['ma_5finclude_5foverlay_5fground',['MA_INCLUDE_OVERLAY_GROUND',['../_m_a_config_8h.html#add7d7778a59b4909c5901e5e5cf2671c',1,'MAConfig.h']]],
  ['ma_5finclude_5foverlay_5fheatmap',['MA_INCLUDE_OVERLAY_HEATMAP',['../_m_a_config_8h.html#af3faaaa5b7347582d8f8639e635edb55',1,'MAConfig.h']]],
  ['ma_5finclude_5ftrace_5fcorrect',['MA_INCLUDE_TRACE_CORRECT',['../_m_a_config_8h.html#a72dec477240eb7bbf156a26b790bbe7c',1,'MAConfig.h']]],
  ['ma_5finclude_5fworldmap',['MA_INCLUDE_WORLDMAP',['../_m_a_config_8h.html#a8f9794bede655efc0d9904cebbdc48f3',1,'MAConfig.h']]],
  ['mamapminrequiredfoundationversion',['MAMapMinRequiredFoundationVersion',['../_m_a_map_version_8h.html#a4e506d09ecc84ecbc18bf1cce6b585b2',1,'MAMapVersion.h']]],
  ['mamapversionnumber',['MAMapVersionNumber',['../_m_a_map_version_8h.html#ad1ce79bfa2ff6849f765dc020e10b750',1,'MAMapVersion.h']]]
];
