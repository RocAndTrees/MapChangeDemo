var searchData=
[
  ['takesnapshotinrect_3a',['takeSnapshotInRect:',['../interface_m_a_map_view.html#af5fdbd95460a6aaf3e8e25dea0f22ca2',1,'MAMapView']]],
  ['takesnapshotinrect_3awithcompletionblock_3a',['takeSnapshotInRect:withCompletionBlock:',['../interface_m_a_map_view.html#a12ac594ec897b0298581c920a2287277',1,'MAMapView']]]
];
