var interface_m_a_multi_point =
[
    [ "getCoordinates:range:", "interface_m_a_multi_point.html#adb088c10f31c8ad2930e8af0200350e4", null ],
    [ "_boundingRect", "interface_m_a_multi_point.html#aa18598bd69f769593fbb7eb0e791495e", null ],
    [ "_pointCount", "interface_m_a_multi_point.html#a689706d4b90404fd1d287715f3c01acc", null ],
    [ "_points", "interface_m_a_multi_point.html#ae7a16a5293d209b2b254fef1cc56f3df", null ],
    [ "pointCount", "interface_m_a_multi_point.html#af7b3e6d897988d9417de41ef5efbfae7", null ],
    [ "points", "interface_m_a_multi_point.html#a20582f70a9e18f21fc2b72aa3fecab5b", null ]
];