var _m_a_trace_manager_8h =
[
    [ "MATraceManager", "interface_m_a_trace_manager.html", "interface_m_a_trace_manager" ],
    [ "MAFailedCallback", "_m_a_trace_manager_8h.html#aba7540736738cf26040d70b5c961fd0e", null ],
    [ "MAFinishCallback", "_m_a_trace_manager_8h.html#a670d06d2176c7394106f4f580cc9de70", null ],
    [ "MAProcessingCallback", "_m_a_trace_manager_8h.html#a98bc4d793a9ff96286d0451d580a30a6", null ]
];