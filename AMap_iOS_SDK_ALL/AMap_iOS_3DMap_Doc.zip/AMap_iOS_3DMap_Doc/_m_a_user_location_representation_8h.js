var _m_a_user_location_representation_8h =
[
    [ "MAUserLocationRepresentation", "interface_m_a_user_location_representation.html", "interface_m_a_user_location_representation" ],
    [ "kAccuracyCircleDefaultColor", "_m_a_user_location_representation_8h.html#a3772016cba673eedbca5143e64a777a8", null ]
];