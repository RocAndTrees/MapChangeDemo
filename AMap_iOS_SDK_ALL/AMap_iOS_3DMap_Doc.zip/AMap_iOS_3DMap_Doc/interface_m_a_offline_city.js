var interface_m_a_offline_city =
[
    [ "cityCode", "interface_m_a_offline_city.html#a43c9b41a091bd28915f56c8102031057", null ],
    [ "cityName", "interface_m_a_offline_city.html#a54ada02aafa82f86f7d4e24a64d083c1", null ],
    [ "status", "interface_m_a_offline_city.html#a3e5a221e04fee3272866b65eb723903d", null ],
    [ "urlString", "interface_m_a_offline_city.html#a34a962e36ecf746e34a25535f637576c", null ]
];