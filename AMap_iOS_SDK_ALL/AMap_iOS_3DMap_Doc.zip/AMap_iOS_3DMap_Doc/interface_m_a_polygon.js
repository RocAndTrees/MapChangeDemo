var interface_m_a_polygon =
[
    [ "setPolygonWithCoordinates:count:", "interface_m_a_polygon.html#a499586fdb35a81837bbd6f8758e50db0", null ],
    [ "setPolygonWithPoints:count:", "interface_m_a_polygon.html#afe2295d344b06c22b233c39078f0fa31", null ]
];