var interface_m_a_tile_overlay_renderer =
[
    [ "initWithTileOverlay:", "interface_m_a_tile_overlay_renderer.html#a29ac1e3617e72a1a3c5547d25fca7ab8", null ],
    [ "reloadData", "interface_m_a_tile_overlay_renderer.html#aa7e8ceb17e2af2777441fe7fd3ee0c22", null ],
    [ "tileOverlay", "interface_m_a_tile_overlay_renderer.html#a5fcdcbd7f0a6bb14dcb27249ba6f0edb", null ]
];