var category_m_a_offline_map_07_deprecated_08 =
[
    [ "downloadCity:downloadBlock:", "category_m_a_offline_map_07_deprecated_08.html#a4c5a91d43888130250ab57cd377c7f68", null ],
    [ "downloadCity:shouldContinueWhenAppEntersBackground:downloadBlock:", "category_m_a_offline_map_07_deprecated_08.html#a74002c4eb9a6022903261ddf56039f1c", null ],
    [ "isDownloadingForCity:", "category_m_a_offline_map_07_deprecated_08.html#add17492e861f9ffe3471e4b80eca5eb9", null ],
    [ "pause:", "category_m_a_offline_map_07_deprecated_08.html#a8d8b158cb05002145a6d4edb08d7a385", null ],
    [ "offlineCities", "category_m_a_offline_map_07_deprecated_08.html#af9fee89e41d51c0031bfb2be49f585ab", null ]
];