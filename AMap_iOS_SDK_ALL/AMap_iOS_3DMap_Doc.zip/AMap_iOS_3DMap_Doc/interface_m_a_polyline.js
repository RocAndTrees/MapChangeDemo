var interface_m_a_polyline =
[
    [ "setPolylineWithCoordinates:count:", "interface_m_a_polyline.html#a35d1d920f368e0d9927bc1731b2ef859", null ],
    [ "setPolylineWithPoints:count:", "interface_m_a_polyline.html#abe4c7dbfa9ae318d0f784ab3e2a7ba7a", null ]
];