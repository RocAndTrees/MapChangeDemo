var _m_a_config_8h =
[
    [ "MA_CUSTOM_MAP", "_m_a_config_8h.html#a71853293c03d1f5fcbf83d9d4accd926", null ],
    [ "MA_INCLUDE_CACHE", "_m_a_config_8h.html#a9d505e549528fcb823446a23a0867eef", null ],
    [ "MA_INCLUDE_INDOOR", "_m_a_config_8h.html#a3aaa6b8b3d9f1718a1fd5362a6107dc7", null ],
    [ "MA_INCLUDE_OFFLINE", "_m_a_config_8h.html#a3db51d6b8d16301a42ca14c8271d6409", null ],
    [ "MA_INCLUDE_OVERLAY_GEODESIC", "_m_a_config_8h.html#aee78790b7b8c3303f37173f76c3e0036", null ],
    [ "MA_INCLUDE_OVERLAY_GROUND", "_m_a_config_8h.html#add7d7778a59b4909c5901e5e5cf2671c", null ],
    [ "MA_INCLUDE_OVERLAY_HEATMAP", "_m_a_config_8h.html#af3faaaa5b7347582d8f8639e635edb55", null ],
    [ "MA_INCLUDE_TRACE_CORRECT", "_m_a_config_8h.html#a72dec477240eb7bbf156a26b790bbe7c", null ],
    [ "MA_INCLUDE_WORLDMAP", "_m_a_config_8h.html#a8f9794bede655efc0d9904cebbdc48f3", null ]
];