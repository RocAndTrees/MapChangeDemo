var interface_m_a_trace_point =
[
    [ "latitude", "interface_m_a_trace_point.html#ad6a15d654779f43a4559ff0c4f7bfbf6", null ],
    [ "longitude", "interface_m_a_trace_point.html#a1e7518421ae4340d5444073e73babb82", null ]
];