var interface_m_a_geodesic_polyline =
[
    [ "setPolylineWithCoordinates:count:", "interface_m_a_geodesic_polyline.html#ae3244ade2b64d19f7dde6df24ccb1d82", null ],
    [ "setPolylineWithPoints:count:", "interface_m_a_geodesic_polyline.html#a294230ed43b70e1e2ab3918b3b6558bf", null ]
];