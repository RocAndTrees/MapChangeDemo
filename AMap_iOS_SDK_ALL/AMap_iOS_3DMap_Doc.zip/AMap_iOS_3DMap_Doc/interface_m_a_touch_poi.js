var interface_m_a_touch_poi =
[
    [ "coordinate", "interface_m_a_touch_poi.html#a48c1f1f9bd282adb986c2c0cdf43f4db", null ],
    [ "name", "interface_m_a_touch_poi.html#aaa06c22e6ae8674efee379c3b165d080", null ],
    [ "uid", "interface_m_a_touch_poi.html#a38f702e8b2bda5e5abef734c9ae7c0f6", null ]
];