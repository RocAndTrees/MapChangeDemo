var protocol_m_a_annotation_01_p =
[
    [ "setCoordinate:", "protocol_m_a_annotation_01-p.html#aa0e3b7bf6ca25dc4df746f30f35bdd3d", null ],
    [ "coordinate", "protocol_m_a_annotation_01-p.html#a69af44c1bc7faf7f52175b76e71e1036", null ],
    [ "subtitle", "protocol_m_a_annotation_01-p.html#a5477928cfd28bf64e6b0dfaff6140174", null ],
    [ "title", "protocol_m_a_annotation_01-p.html#a0fb719a65e0a29cfef83dae09b3ce111", null ]
];