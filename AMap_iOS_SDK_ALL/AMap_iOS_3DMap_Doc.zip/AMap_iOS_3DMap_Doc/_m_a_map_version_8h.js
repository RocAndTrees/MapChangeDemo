var _m_a_map_version_8h =
[
    [ "MAMapMinRequiredFoundationVersion", "_m_a_map_version_8h.html#a4e506d09ecc84ecbc18bf1cce6b585b2", null ],
    [ "MAMapVersionNumber", "_m_a_map_version_8h.html#ad1ce79bfa2ff6849f765dc020e10b750", null ],
    [ "MAMapKitName", "_m_a_map_version_8h.html#af61090f94c134af82ac16e9cec77df94", null ],
    [ "MAMapKitVersion", "_m_a_map_version_8h.html#a6840476cfdc65acec4136952737425bc", null ]
];