var interface_m_a_trace_manager =
[
    [ "queryProcessedTraceWith:type:processingCallback:finishCallback:failedCallback:", "interface_m_a_trace_manager.html#ae5ccf179319b25aa9ee57dc2d1e62940", null ]
];