var category_m_a_map_view_07_custom_map_style_08 =
[
    [ "setCustomMapStyle:", "category_m_a_map_view_07_custom_map_style_08.html#a37f64995032c89ae6ee2c0e7ddcf65a3", null ],
    [ "customMapStyleEnabled", "category_m_a_map_view_07_custom_map_style_08.html#a6b75e0a681ccd4be1ef4e8df8aa42b6d", null ]
];