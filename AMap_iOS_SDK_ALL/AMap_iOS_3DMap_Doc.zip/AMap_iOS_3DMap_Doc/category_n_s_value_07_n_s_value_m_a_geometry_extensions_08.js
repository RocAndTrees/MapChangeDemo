var category_n_s_value_07_n_s_value_m_a_geometry_extensions_08 =
[
    [ "MACoordinateValue", "category_n_s_value_07_n_s_value_m_a_geometry_extensions_08.html#aca014bfe2761e392be070f9cd2d204c3", null ],
    [ "MAMapPointValue", "category_n_s_value_07_n_s_value_m_a_geometry_extensions_08.html#a275621b13626ac8013ad3cf0bb44d70f", null ],
    [ "MAMapRectValue", "category_n_s_value_07_n_s_value_m_a_geometry_extensions_08.html#a26b2ee41760da98fa76a5edd37c7f451", null ],
    [ "MAMapSizeValue", "category_n_s_value_07_n_s_value_m_a_geometry_extensions_08.html#a3969bd608a28caa8eebabaa147f5621d", null ]
];