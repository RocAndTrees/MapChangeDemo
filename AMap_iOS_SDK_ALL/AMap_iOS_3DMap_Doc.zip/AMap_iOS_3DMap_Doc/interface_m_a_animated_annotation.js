var interface_m_a_animated_annotation =
[
    [ "addMoveAnimationWithKeyCoordinates:count:withDuration:withName:completeCallback:", "interface_m_a_animated_annotation.html#a5a3093038d6ac77fd0d51ca0de553b86", null ],
    [ "allMoveAnimations", "interface_m_a_animated_annotation.html#a39c79e6e542a67041c0d44ebb907ebbb", null ],
    [ "movingDirection", "interface_m_a_animated_annotation.html#ab80b10c6c31cca2236a6e8d7ede12b47", null ]
];