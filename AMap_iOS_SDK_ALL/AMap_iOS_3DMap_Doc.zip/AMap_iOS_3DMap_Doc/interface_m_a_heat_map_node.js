var interface_m_a_heat_map_node =
[
    [ "coordinate", "interface_m_a_heat_map_node.html#a3001789a8e348a8b0b1971efb7bd2145", null ],
    [ "intensity", "interface_m_a_heat_map_node.html#ac237cc2293a56a5f356c43c75ba67505", null ]
];