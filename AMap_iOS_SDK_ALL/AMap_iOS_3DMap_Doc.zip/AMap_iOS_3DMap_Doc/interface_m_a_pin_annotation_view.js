var interface_m_a_pin_annotation_view =
[
    [ "animatesDrop", "interface_m_a_pin_annotation_view.html#af3e8dd35184ab98a283de97a3d1088ea", null ],
    [ "pinColor", "interface_m_a_pin_annotation_view.html#aac7cb690aff58f86709d8e807f542d6a", null ]
];