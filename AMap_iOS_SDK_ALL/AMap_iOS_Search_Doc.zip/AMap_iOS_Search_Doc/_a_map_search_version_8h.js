var _a_map_search_version_8h =
[
    [ "AMapSearchMinRequiredFoundationVersion", "_a_map_search_version_8h.html#abbe9fbc6f627de58b3b9bb43fc0876b9", null ],
    [ "AMapSearchVersionNumber", "_a_map_search_version_8h.html#a4720ef1eec9516b2414a2b0f83ccca71", null ],
    [ "AMapSearchName", "_a_map_search_version_8h.html#a9950dcedd325e9db19e4b609472dc0a9", null ],
    [ "AMapSearchVersion", "_a_map_search_version_8h.html#afcd0318aafc54f9ba6485fa2c1ac523f", null ]
];