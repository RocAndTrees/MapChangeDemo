var interface_a_map_nearby_user_info =
[
    [ "distance", "interface_a_map_nearby_user_info.html#a0e9a11991e64f978233c21cd8ce545a8", null ],
    [ "location", "interface_a_map_nearby_user_info.html#aaa2f6c67544f2ed2cfa7391945e52484", null ],
    [ "updatetime", "interface_a_map_nearby_user_info.html#a4d752681d40f0f7bcae1d484f43055e5", null ],
    [ "userID", "interface_a_map_nearby_user_info.html#a3e2a3684eed555835d8528f658494f8d", null ]
];