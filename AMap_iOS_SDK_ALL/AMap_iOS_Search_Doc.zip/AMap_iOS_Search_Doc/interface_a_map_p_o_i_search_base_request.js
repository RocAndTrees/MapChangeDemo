var interface_a_map_p_o_i_search_base_request =
[
    [ "building", "interface_a_map_p_o_i_search_base_request.html#afd433275e4e1ea0cd830d32aab8a3eec", null ],
    [ "offset", "interface_a_map_p_o_i_search_base_request.html#a58e9fb39f76d309770483ce7f88197dd", null ],
    [ "page", "interface_a_map_p_o_i_search_base_request.html#a3d41f26dd933c837b9deebe4b05bac33", null ],
    [ "requireExtension", "interface_a_map_p_o_i_search_base_request.html#a0b1d41def4ee3baf093b5c6e0d8349f1", null ],
    [ "requireSubPOIs", "interface_a_map_p_o_i_search_base_request.html#accdad359e5fa155b352fde3a009b9ac2", null ],
    [ "sortrule", "interface_a_map_p_o_i_search_base_request.html#afae1582ad4d98b2d2f28be56e5019439", null ],
    [ "types", "interface_a_map_p_o_i_search_base_request.html#a6ac4aea8ffa7542c32f9b3c923d10c3d", null ]
];