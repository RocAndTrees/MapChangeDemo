var _a_map_nearby_upload_info_8h =
[
    [ "AMapNearbyUploadInfo", "interface_a_map_nearby_upload_info.html", "interface_a_map_nearby_upload_info" ],
    [ "AMapSearchCoordinateType", "_a_map_nearby_upload_info_8h.html#a36d0c042422cbe18233a004f7433df74", [
      [ "AMapSearchCoordinateTypeGPS", "_a_map_nearby_upload_info_8h.html#a36d0c042422cbe18233a004f7433df74abc4aa7e6bde0c40c626809592158622d", null ],
      [ "AMapSearchCoordinateTypeAMap", "_a_map_nearby_upload_info_8h.html#a36d0c042422cbe18233a004f7433df74a036dd98339be8e9fe8828ab40333bb24", null ]
    ] ]
];