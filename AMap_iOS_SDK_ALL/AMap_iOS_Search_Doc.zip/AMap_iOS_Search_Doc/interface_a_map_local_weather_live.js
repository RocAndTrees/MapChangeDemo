var interface_a_map_local_weather_live =
[
    [ "adcode", "interface_a_map_local_weather_live.html#a956930770fdfae8ed83dc4c7ce15c439", null ],
    [ "city", "interface_a_map_local_weather_live.html#aef98f1b582d502e9efb2a90db6757aa1", null ],
    [ "humidity", "interface_a_map_local_weather_live.html#ab5f1b1968f82097011efa41e63f416fd", null ],
    [ "province", "interface_a_map_local_weather_live.html#a62b2bef7ddbfbb5bcdbf5d60c474c357", null ],
    [ "reportTime", "interface_a_map_local_weather_live.html#a4ac1f103707818633d49f3356b4ca64c", null ],
    [ "temperature", "interface_a_map_local_weather_live.html#a6cda298292f5f36feea066b346772c1a", null ],
    [ "weather", "interface_a_map_local_weather_live.html#a5fc4d81baceab799c32aea05222ae087", null ],
    [ "windDirection", "interface_a_map_local_weather_live.html#a98ae1fab416c024d950e2afa9b2be43f", null ],
    [ "windPower", "interface_a_map_local_weather_live.html#a612c98336a13b4c404227d9c8c6d950d", null ]
];