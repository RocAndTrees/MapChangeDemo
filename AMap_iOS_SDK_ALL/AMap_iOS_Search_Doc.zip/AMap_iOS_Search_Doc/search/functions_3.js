var searchData=
[
  ['init',['init',['../interface_a_map_nearby_search_manager.html#aecfcca521f45087fbf93015ca5076304',1,'AMapNearbySearchManager::init()'],['../interface_a_map_search_a_p_i.html#a1b77a0f91212f8c0210ca0cd6903f55b',1,'AMapSearchAPI::init()']]]
];
