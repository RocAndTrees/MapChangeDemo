var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvw",
  1: "a",
  2: "a",
  3: "acfilnopsu",
  4: "a",
  5: "a",
  6: "a",
  7: "abcdefghiklmnoprstuvw",
  8: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Macros"
};

