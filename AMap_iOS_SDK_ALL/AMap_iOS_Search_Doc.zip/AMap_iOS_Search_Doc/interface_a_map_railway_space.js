var interface_a_map_railway_space =
[
    [ "code", "interface_a_map_railway_space.html#af49af153637d0462c05de012b726bc33", null ],
    [ "cost", "interface_a_map_railway_space.html#ac3a863fc4a972aceb47794f6dfebc982", null ]
];