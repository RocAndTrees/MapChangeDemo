var interface_a_map_re_geocode_search_request =
[
    [ "location", "interface_a_map_re_geocode_search_request.html#a874c1c507c0b27f85285acb0adabc20c", null ],
    [ "radius", "interface_a_map_re_geocode_search_request.html#a74efc907f4057d8e7a148335289548d9", null ],
    [ "requireExtension", "interface_a_map_re_geocode_search_request.html#a7853296f29607051a4f41f520206ea79", null ]
];