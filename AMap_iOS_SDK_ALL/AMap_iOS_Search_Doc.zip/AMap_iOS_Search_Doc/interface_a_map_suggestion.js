var interface_a_map_suggestion =
[
    [ "cities", "interface_a_map_suggestion.html#aa9c189629b248bbad64033a08afad27b", null ],
    [ "keywords", "interface_a_map_suggestion.html#a50e504eb33a5fbb4d58073c6a5101892", null ]
];