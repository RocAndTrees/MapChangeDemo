var interface_a_map_nearby_search_request =
[
    [ "center", "interface_a_map_nearby_search_request.html#a955e48688ee8401ff3d126fa73a5f9f4", null ],
    [ "limit", "interface_a_map_nearby_search_request.html#a499b22335a1f4079c8b64cdd30e867e0", null ],
    [ "radius", "interface_a_map_nearby_search_request.html#ad4a0e5141c57b3355da78d2a794ab06b", null ],
    [ "searchType", "interface_a_map_nearby_search_request.html#a7fabd888dca071e86f1ce25a573d8f84", null ],
    [ "timeRange", "interface_a_map_nearby_search_request.html#a66b6279c13a3ce319df88d26b1080b0b", null ]
];