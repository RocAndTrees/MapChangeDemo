var interface_a_map_taxi =
[
    [ "destination", "interface_a_map_taxi.html#a18bfc2e3617fcf077a3f48416817bab3", null ],
    [ "distance", "interface_a_map_taxi.html#a8c94faf51cd0a568580ddc3b1e9adb95", null ],
    [ "duration", "interface_a_map_taxi.html#a9b0c8c0fff3d74d245b67afd3d594a08", null ],
    [ "origin", "interface_a_map_taxi.html#afd947a99078a46d35c382550f3e33a37", null ],
    [ "sname", "interface_a_map_taxi.html#add12d541d602fb513554cee0ec389393", null ],
    [ "tname", "interface_a_map_taxi.html#a150fec9a3f786fe0da0da0a52d9d8dd9", null ]
];