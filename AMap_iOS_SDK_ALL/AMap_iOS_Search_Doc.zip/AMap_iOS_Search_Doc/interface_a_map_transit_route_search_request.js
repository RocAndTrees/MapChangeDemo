var interface_a_map_transit_route_search_request =
[
    [ "city", "interface_a_map_transit_route_search_request.html#ad31186efa2e71823c424f9dd22bac182", null ],
    [ "destinationCity", "interface_a_map_transit_route_search_request.html#a0d9dcec73841812b70a13dcb2962fa2b", null ],
    [ "nightflag", "interface_a_map_transit_route_search_request.html#a964450c1d66745a80b0e379f55607050", null ],
    [ "requireExtension", "interface_a_map_transit_route_search_request.html#a685cb04f639c7aba988ba5092d348761", null ],
    [ "strategy", "interface_a_map_transit_route_search_request.html#a44577f9dbf9045ded920697a960c3d1f", null ]
];