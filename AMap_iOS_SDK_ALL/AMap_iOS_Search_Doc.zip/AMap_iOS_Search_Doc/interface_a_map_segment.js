var interface_a_map_segment =
[
    [ "buslines", "interface_a_map_segment.html#a7def540a285700e92ca7f1d5548f1cd8", null ],
    [ "enterLocation", "interface_a_map_segment.html#acb7b364d36e4023ca7789ce0abd69d8b", null ],
    [ "enterName", "interface_a_map_segment.html#afafd0edb58fbbe1e248e000147bf7afa", null ],
    [ "exitLocation", "interface_a_map_segment.html#a865dd34f7ef1693536cd50196ae159a2", null ],
    [ "exitName", "interface_a_map_segment.html#a172de8156b2eef10c5f303769aeb587a", null ],
    [ "railway", "interface_a_map_segment.html#a2670287c2a13e9b9c36b114d8a1db828", null ],
    [ "taxi", "interface_a_map_segment.html#a0f0fda8e826fc383920212f5d955efc4", null ],
    [ "walking", "interface_a_map_segment.html#ac7cc248ef42b0f4e3f32f9340c2f9596", null ]
];