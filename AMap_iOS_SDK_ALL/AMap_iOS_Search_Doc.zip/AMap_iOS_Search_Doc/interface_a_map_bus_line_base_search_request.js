var interface_a_map_bus_line_base_search_request =
[
    [ "city", "interface_a_map_bus_line_base_search_request.html#a9ea33ab0e9181c1515803cc4f8a4f1f4", null ],
    [ "offset", "interface_a_map_bus_line_base_search_request.html#a4fe622db3c1330469871c4d8ee63b77e", null ],
    [ "page", "interface_a_map_bus_line_base_search_request.html#a92e5a70f41ff5c4737dd272db0a42f08", null ],
    [ "requireExtension", "interface_a_map_bus_line_base_search_request.html#a25255df237b5e7c73e51e82ad3b09a49", null ]
];