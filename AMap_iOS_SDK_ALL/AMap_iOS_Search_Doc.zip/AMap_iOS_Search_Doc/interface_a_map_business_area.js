var interface_a_map_business_area =
[
    [ "location", "interface_a_map_business_area.html#a6a487bf4989635998f7e8a2d680dcf91", null ],
    [ "name", "interface_a_map_business_area.html#ae16002adf68286cb68f1a70a6a588e94", null ]
];