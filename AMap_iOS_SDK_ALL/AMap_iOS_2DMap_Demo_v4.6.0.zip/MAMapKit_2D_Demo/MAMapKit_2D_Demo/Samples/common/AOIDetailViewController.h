//
//  AOIDetailViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 16/2/22.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchKit.h>

@interface AOIDetailViewController : UIViewController

@property (nonatomic, strong) AMapAOI *aoi;

@end
