//
//  RoutePOIDetailViewController.h
//  MAMapKit_2D_Demo
//
//  Created by xiaoming han on 16/9/5.
//  Copyright © 2016年 Autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapCommonObj.h>

@interface RoutePOIDetailViewController : UIViewController

@property (nonatomic, strong) AMapRoutePOI *routePOI;

@end
