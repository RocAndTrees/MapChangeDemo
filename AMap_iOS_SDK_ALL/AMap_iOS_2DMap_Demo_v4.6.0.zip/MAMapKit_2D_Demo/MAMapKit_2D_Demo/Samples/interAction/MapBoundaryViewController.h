//
//  MapBoundaryViewController.h
//  MAMapKit
//
//  Created by shaobin on 16/8/30.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MAMapKit/MAMapKit.h>

@interface MapBoundaryViewController : UIViewController

@end
