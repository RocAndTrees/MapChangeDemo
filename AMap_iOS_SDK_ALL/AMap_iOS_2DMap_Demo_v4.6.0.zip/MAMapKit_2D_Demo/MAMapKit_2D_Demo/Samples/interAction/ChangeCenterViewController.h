//
//  ChangeCenterViewController.h
//  MAMapKit_2D_Demo
//
//  Created by shaobin on 16/8/16.
//  Copyright © 2016年 Autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangeCenterViewController : UIViewController

@end
