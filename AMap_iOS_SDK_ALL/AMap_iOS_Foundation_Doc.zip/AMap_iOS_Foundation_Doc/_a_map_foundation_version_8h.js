var _a_map_foundation_version_8h =
[
    [ "AMapFoundationVersionNumber", "_a_map_foundation_version_8h.html#a1879116222bba8b541eb9437a426f8cb", null ],
    [ "AMapFoundationName", "_a_map_foundation_version_8h.html#ab644956393c574f5294cd0d1248db821", null ],
    [ "AMapFoundationVersion", "_a_map_foundation_version_8h.html#a5a58116a466e4d02f276427ba4af1eb2", null ]
];