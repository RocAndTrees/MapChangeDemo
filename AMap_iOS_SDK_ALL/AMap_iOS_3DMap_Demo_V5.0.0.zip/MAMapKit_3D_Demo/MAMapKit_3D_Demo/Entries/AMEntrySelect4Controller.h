//
//  AMEntrySelect4Controller.h
//  MAMapKit_3D_Demo
//
//  Created by shaobin on 16/8/11.
//  Copyright © 2016年 Autonavi. All rights reserved.
//

#import "AMBaseEntrySelectController.h"

@interface AMEntrySelect4Controller : AMBaseEntrySelectController

@end
