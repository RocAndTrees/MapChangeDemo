//
//  RailwayDetailViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 16/7/29.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface RailwayDetailViewController : UIViewController

@property (nonatomic, strong) AMapRailway *railway;

@end
