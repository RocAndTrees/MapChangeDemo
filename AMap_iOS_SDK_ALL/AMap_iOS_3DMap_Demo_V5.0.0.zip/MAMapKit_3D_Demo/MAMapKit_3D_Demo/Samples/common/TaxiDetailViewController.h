//
//  TaxiDetailViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 16/8/8.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface TaxiDetailViewController : UIViewController

@property (nonatomic, strong) AMapTaxi *taxi;

@end